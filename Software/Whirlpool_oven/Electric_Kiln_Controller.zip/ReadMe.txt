Manual for Electric Kiln Controller v1.0
----------------------------------------

  This program was created to control an electric kiln with a Arduino microcontroller.
  It was primarly made as a conversion from a manual controller (Kiln Sitter) to a digital controller for glass fusing, but can be used for other types of kilns.

DISCLAIMER:
  There is no warranty expressed / implied with this free software.  This program works with my kiln and may (or may not) work with yours.
  It is your resposibility to modify / check the program and make sure it works properly / safely with your kiln.
  Do not leave your kiln unattended.
  It is not my responsibility if it ruins your art, burns down your house, becomes sentient and starts world war 3, etc.
  Please do not forward this program without this ReadMe file and examples.
  Do not use this program for commercial / resale use.

Features:
 - Unlimited firing schedules stored on MicroSD card.
 - Each schedule can have up to 20 segments (more if your memory allows).  Each segment has its own ramp rate, target temperature, and hold time.  
 - Control up to 3 zones.  These are areas in your kiln with separate heating elements and thermocouples.
 - Fahrenheit or Celsius temperature scales.  Max temperature reading of 1875F / 1024C (higher if you use a MAX31855 card)
 - Shutdown if max temperature is reached.
 - PID loop control of heating elements.
 - Temperature logging to file on MicroSD card for analysis.

Schedule file format:
 - The firing schedule files must be saved in a specific format to work (see examples):
    - Saved as a text file (*.txt)
    - The file name must be a number.  The first file should be 1.  Example: 1.txt, 2.txt, 3.txt
    - Save files in the root directory of the MicroSD card.
    - The first 3 lines are used for a description of the schedule.  20 characters max (each line).  Add a blank line if you don't need all 3 lines.
    - The following lines are the segments to control the temperature during each phase of the firing schedule:
       - Separate each number with a comma.  No spaces.  Only integers (no decimal points).
       - The first number is the ramp rate (degrees / hour).  This is how fast the kiln tries to get to the target temp.  If you want as fast as possible, enter 9999.
       - The second number is the target temperature (degrees).
       - The third number is the hold time (minutes).  This is how long it will hold the target temperature after it has been reached.  If you don't need to hold, enter zero.
         Do not enter hours (ex: for 2 hours, enter 120)

Save temp file format:
  - Saved as text file in CSV format (comma separated).  File name is "TEMPS.TXT" in root directory of SD card.
  - The old file is deleted once you start the Arduino.
  - First field is minutes from when you started running the schedule.
  - Next field(s) is current temperature reading.  One for each zone.
  - Last field is current setpoint temperature (target).

My Setup:
 - Arduino UNO (this model will only control one zone)
 - SunFounder LCD2004, 20 x 4 LCD
 - Adafruit ADA254, MicroSD card reader
 - Aideepen MAX6675 thermocouple module (get MAX31855 if you need to read temps higher than 1875F / 1024C)
 - ANV SSR-25DA relay with heat sink
 - On/off switch and 3 buttons (up / down / select).  LED to show when it is heating.
 - 12V power supply (25W)
 - 12V cooling fan

Your Setup:
 - For safety reasons, you should include a separate temperature controller in the wiring to shut down power if max temperature is reached.
 - To make this work with your kiln / wiring, you need to modify the Arduino program:
    - User variables.  This the 3rd paragraph in the program.
    - Pin connections.  This is the 4th paragraph in the program.

Running:
 - The program will start by showing the number and description of schedule #1 (from file "1.txt")
 - Use the up / down buttons to highlight the schedule you want to run.  Hit select button to start running the program.
 - When running, use the up / down buttons to see different screens:
    - The temp screen shows the actual and target (set point) temperatures for each zone
    - The schedule screen shows the description and where it is currently at in the program
    - The tools screen lets you make changes to the program when running.  Use the select button to activate.
       - Add 5 more minutes to the hold time
       - Increase the target temperature by 5 degrees
       - Skip to the next segment

PID Tuning:
 - For best performance, you need to "tune" the PID loops.  This is a method to calculate the Kp, Ki, and Kd values for optimum performance.  You should do a Google search on this.
 - Here is how I tuned mine:
    - Set Kp to some low value.  Set Ki and Kd to zero.   
    - Create and run a schedule that ramps and holds an average temp that you will use.
    - Watch the temperatures.  You are looking for the temps to make a steady cycle around the setpoint value.  The temp should go slightly above the setpoint, then drop down, and repeat.
    - If the temps do not go above the setpoint, double the Kp value and try again.  If you think you are getting close, then only increase by 50%.  This can take some time.
    - Once you get a steady cycle, record the period (in seconds).  This is the time it takes to make one complete cycle (high temp to next high temp).  The save file comes in handy here.
    - Set Kp to half of the Kp you used to get a steady cycle.
    - Set Ki to the period times 1.2
    - Set Kd to the period divided by 8
    - Run a test schedule to see how you did.

Contact me if you have problems / suggestions
  Steve Turner
  arduinokiln@gmail.com